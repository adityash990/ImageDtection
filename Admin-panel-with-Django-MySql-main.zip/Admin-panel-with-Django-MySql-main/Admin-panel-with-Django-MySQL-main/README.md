# Admin Panel with Django MySQL By Aditya Sharma

### Build with
- [Django](https://docs.djangoproject.com/en/4.0/)
- [MySQL](https://www.mysql.com/)
- [Bootstrap](https://getbootstrap.com/)

### Dependencies
