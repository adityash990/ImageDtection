from django.contrib import admin

from . models import schedular
# Register your models here.

admin.site.register(schedular)